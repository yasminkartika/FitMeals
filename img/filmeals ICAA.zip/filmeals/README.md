# Filmeals - Halaman Notifikasi

Halaman notifikasi modern untuk aplikasi Filmeals yang dibangun dengan Tailwind CSS.

## Fitur

### 🎨 Desain Modern

- Interface yang bersih dan modern menggunakan Tailwind CSS
- Warna tema orange yang konsisten dengan brand Filmeals
- Responsive design untuk desktop dan mobile
- Animasi hover dan transisi yang smooth

### 🔔 Sistem Notifikasi

- **Notifikasi Belum Dibaca**: Ditandai dengan dot merah
- **Kategori Notifikasi**: Pesanan, Promo, Sistem, Menu, Pengiriman
- **Status Waktu**: Menampilkan waktu relatif (2 menit yang lalu, 1 jam yang lalu, dll)
- **Filter Notifikasi**: Filter berdasarkan kategori
- **Mark as Read**: Fungsi untuk menandai notifikasi sebagai sudah dibaca

### 📱 Komponen UI

- **Header**: Logo Filmeals, search bar, notifikasi bell, dan user profile
- **Page Header**: Judul halaman dengan action buttons
- **Filter Tabs**: Filter notifikasi berdasarkan kategori
- **Notification Cards**: Card design untuk setiap notifikasi
- **Action Buttons**: Tombol untuk berbagai aksi (Lihat Detail, Klaim Promo, dll)

### 🎯 Jenis Notifikasi

1. **Pesanan Berhasil** - Konfirmasi pesanan yang berhasil diproses
2. **Promo Spesial** - Penawaran dan diskon khusus
3. **Pembaruan Sistem** - Informasi update aplikasi
4. **Menu Baru** - Pengumuman menu terbaru
5. **Pengiriman** - Status pengiriman pesanan

## Teknologi yang Digunakan

- **HTML5** - Struktur halaman
- **Tailwind CSS** - Framework CSS untuk styling
- **Font Awesome** - Icon library
- **JavaScript** - Interaktivitas dan fungsi

## Cara Menjalankan

1. Buka file `index.html` di browser web
2. Atau gunakan live server untuk development

## Struktur File

```
filmeals/
├── index.html          # Halaman utama notifikasi
└── README.md          # Dokumentasi proyek
```

## Fitur Interaktif

### Filter Notifikasi

- Klik pada tab filter untuk mengubah kategori yang ditampilkan
- Tab aktif akan memiliki background orange

### Mark as Read

- Klik tombol "Tandai Dibaca" untuk menandai notifikasi sebagai sudah dibaca
- Dot merah akan hilang dan opacity card akan berkurang

### Responsive Design

- Halaman responsive untuk berbagai ukuran layar
- Layout menyesuaikan untuk mobile dan desktop

## Customization

### Warna Tema

Warna utama Filmeals menggunakan:

- Primary: `orange-500` (#F97316)
- Secondary: `orange-600` (#EA580C)
- Accent: `orange-400` (#FB923C)

### Menambah Notifikasi Baru

Untuk menambah notifikasi baru, copy template berikut:

```html
<div
  class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200 cursor-pointer"
>
  <div class="flex items-start space-x-4">
    <div class="flex-shrink-0">
      <div
        class="w-10 h-10 bg-[color]-100 rounded-full flex items-center justify-center"
      >
        <i class="fas fa-[icon] text-[color]-600 text-lg"></i>
      </div>
    </div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center justify-between">
        <p class="text-sm font-medium text-gray-900">Judul Notifikasi</p>
        <div class="flex items-center space-x-2">
          <span
            class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[color]-100 text-[color]-800"
          >
            Kategori
          </span>
          <span class="text-xs text-gray-500">Waktu</span>
        </div>
      </div>
      <p class="mt-1 text-sm text-gray-600">Deskripsi notifikasi...</p>
      <div class="mt-3 flex items-center space-x-4">
        <button
          class="text-sm text-orange-500 hover:text-orange-600 font-medium"
        >
          Action Button
        </button>
        <button class="text-sm text-gray-500 hover:text-gray-700">
          Tandai Dibaca
        </button>
      </div>
    </div>
    <div class="flex-shrink-0">
      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
    </div>
  </div>
</div>
```

## Browser Support

- Chrome (versi terbaru)
- Firefox (versi terbaru)
- Safari (versi terbaru)
- Edge (versi terbaru)

## Lisensi

© 2024 Filmeals. Semua hak dilindungi.
